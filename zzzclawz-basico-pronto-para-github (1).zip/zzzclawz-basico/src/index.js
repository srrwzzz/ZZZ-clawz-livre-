import makeWASocket, {
  DisconnectReason,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore
} from "baileys";
import pino from "pino";
import qrcode from "qrcode-terminal";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const AUTH_DIR = path.join(ROOT, "assets", "auth");
const DB_DIR = path.join(ROOT, "database");
const DB_FILE = path.join(DB_DIR, "users.json");
const PREFIX = process.env.PREFIX || ".";
const BOT_NAME = process.env.BOT_NAME || "Bot Básico";

fs.mkdirSync(AUTH_DIR, { recursive: true });
fs.mkdirSync(DB_DIR, { recursive: true });

function loadUsers() {
  try { return JSON.parse(fs.readFileSync(DB_FILE, "utf8")); }
  catch { return {}; }
}

let users = loadUsers();
function saveUsers() {
  fs.writeFileSync(DB_FILE, JSON.stringify(users, null, 2));
}
function getUser(jid) {
  if (!users[jid]) users[jid] = { nome: "", gold: 0, xp: 0, level: 1, createdAt: new Date().toISOString() };
  return users[jid];
}
function displayName(message) {
  return message.pushName || message.key.participant?.split("@")[0] || "usuário";
}
function textOf(message) {
  return message.message?.conversation || message.message?.extendedTextMessage?.text || "";
}
async function reply(sock, message, text) {
  return sock.sendMessage(message.key.remoteJid, { text }, { quoted: message });
}
function menu() {
  return `👑 *${BOT_NAME}*\n\n` +
    `⛺ *BÁSICOS*\n` +
    `${PREFIX}menu — mostra este menu\n` +
    `${PREFIX}ping — verifica se o bot está online\n` +
    `${PREFIX}perfil — mostra seu perfil\n` +
    `${PREFIX}cadastro <nome> — salva seu nome\n` +
    `${PREFIX}diaria — recebe sua recompensa do dia\n` +
    `${PREFIX}saldo — consulta suas moedas\n` +
    `${PREFIX}dado [lados] — rola um dado\n` +
    `${PREFIX}moeda — cara ou coroa\n` +
    `${PREFIX}info — informações do bot\n\n` +
    `🛟 *GRUPO*\n` +
    `${PREFIX}marcar — marca os participantes\n` +
    `${PREFIX}hidetag <texto> — marca sem listar nomes\n` +
    `${PREFIX}linkgp — envia o link do grupo (admin)\n` +
    `${PREFIX}regras — mostra as regras configuradas\n\n` +
    `🚌 Prefixo atual: ${PREFIX}`;
}
function jidList(participants = []) { return participants.map(p => p.id); }
function randomInt(max) { return Math.floor(Math.random() * max) + 1; }
function today() { return new Date().toISOString().slice(0, 10); }

async function handleCommand(sock, message, command, args) {
  const jid = message.key.remoteJid;
  const sender = message.key.participant || jid;
  const user = getUser(sender);
  const group = jid.endsWith("@g.us");
  const groupMeta = group ? await sock.groupMetadata(jid).catch(() => null) : null;
  const admins = groupMeta?.participants.filter(p => p.admin).map(p => p.id) || [];
  const isAdmin = admins.includes(sender) || admins.includes(jid);
  const needAdmin = () => { if (!isAdmin) reply(sock, message, "🧩 Este comando é somente para administradores."); return isAdmin; };

  switch (command) {
    case "menu": case "ajuda": return reply(sock, message, menu());
    case "ping": return reply(sock, message, `✨ Pong! ${BOT_NAME} está online.`);
    case "info": return reply(sock, message, `📙 *${BOT_NAME}*\nBot básico para WhatsApp.\nNode.js + Baileys\nDados locais em database/users.json`);
    case "cadastro": {
      const nome = args.join(" ").trim();
      if (!nome) return reply(sock, message, `🖍️ Use: ${PREFIX}cadastro <seu nome>`);
      user.nome = nome.slice(0, 40); saveUsers();
      return reply(sock, message, `✅ Cadastro salvo, *${user.nome}*!`);
    }
    case "perfil": case "eu": {
      return reply(sock, message, `🎨 *PERFIL*\nNome: ${user.nome || displayName(message)}\nNível: ${user.level}\nXP: ${user.xp}\nMoedas: ${user.gold}`);
    }
    case "saldo": case "carteira": return reply(sock, message, `🌈 Seu saldo é de *${user.gold} moedas*.`);
    case "diaria": {
      if (user.lastDaily === today()) return reply(sock, message, "⛺ Você já recebeu sua diária hoje.");
      user.gold += 100; user.xp += 10; user.lastDaily = today(); saveUsers();
      return reply(sock, message, "👑 Você recebeu *100 moedas* e *10 XP* na recompensa diária!");
    }
    case "dado": {
      const lados = Math.max(2, Math.min(Number(args[0]) || 6, 100));
      return reply(sock, message, `🎲 Resultado: *${randomInt(lados)}* de ${lados}`);
    }
    case "moeda": case "coinflip": return reply(sock, message, `🚌 Caiu: *${Math.random() < .5 ? "cara" : "coroa"}*`);
    case "marcar": {
      if (!group || !needAdmin()) return;
      return sock.sendMessage(jid, { text: args.join(" ") || "📣 Atenção, pessoal!", mentions: jidList(groupMeta.participants) });
    }
    case "hidetag": {
      if (!group || !needAdmin()) return;
      return sock.sendMessage(jid, { text: args.join(" ") || "📣 Atenção!", mentions: jidList(groupMeta.participants) });
    }
    case "linkgp": {
      if (!group || !needAdmin()) return;
      const code = await sock.groupInviteCode(jid).catch(() => null);
      return reply(sock, message, code ? `🔗 Link do grupo:\nhttps://chat.whatsapp.com/${code}` : "Não consegui obter o link.");
    }
    case "regras": return reply(sock, message, `📙 *REGRAS DO GRUPO*\n\n1. Respeite os participantes.\n2. Não envie spam.\n3. Não publique conteúdo ilegal.\n4. Siga as orientações dos administradores.`);
    default: return reply(sock, message, `🧩 Comando não encontrado. Use ${PREFIX}menu.`);
  }
}

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
  const { version } = await fetchLatestBaileysVersion();
  const sock = makeWASocket({
    version,
    auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" })) },
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    browser: [BOT_NAME, "Chrome", "1.0.0"]
  });
  sock.ev.on("creds.update", saveCreds);
  sock.ev.on("connection.update", ({ connection, lastDisconnect, qr }) => {
    if (qr) qrcode.generate(qr, { small: true });
    if (connection === "open") console.log(`${BOT_NAME} conectado.`);
    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code !== DisconnectReason.loggedOut) start();
      else console.error("Sessão desconectada. Apague assets/auth e conecte novamente.");
    }
  });
  sock.ev.on("messages.upsert", async ({ messages }) => {
    const message = messages[0];
    if (!message?.message || message.key.fromMe) return;
    const raw = textOf(message).trim();
    if (!raw.startsWith(PREFIX)) return;
    const parts = raw.slice(PREFIX.length).trim().split(/\s+/);
    const command = (parts.shift() || "").toLowerCase();
    try { await handleCommand(sock, message, command, parts); }
    catch (error) { console.error(error); await reply(sock, message, "🧩 Ocorreu um erro ao executar este comando."); }
  });
}

start().catch(console.error);
